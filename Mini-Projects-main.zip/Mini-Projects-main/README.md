# Mini-Projects---
Place the HTML,CSS,Js files together in single directory with media files(if any) and click on Html to see the Magic.
